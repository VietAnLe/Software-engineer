package a2_22BI13009.studentman;

import utils.*;

/**
 * @overview This represents a postgraduate student.
 * @attributes
 *    id             Integer     int
 *    name           String      String
 *    phoneNumber    String      String
 *    address        String      String
 *    gpa            Float       float
 * @object
 *    A typical postgraduate student object is post_graduate_student=(id, name, phoneNumber, address, gpa).
 * @abstract_properties
 *    mutable(id)=false /\ optional(id)=false /\ min(id)=10^8 + 1 /\ max(id)=10^9 /\
 *    mutable(name)=true /\ optional(name)=false /\ length(name)=50 /\
 *    mutable(phoneNumber)=true /\ optional(phoneNumber)=false /\ length(phoneNumber)=10 /\
 *    mutable(address)=true /\ optional(address)=false /\ length(address)=100 /\
 *    mutable(gpa)=true /\ optional(gpa)=false /\ min(gpa)=0.0 /\ max(gpa)=4.0
 */
public class PostgradStudent extends Student {
    private static final double MIN_GPA = 0.0;
    private static final double MAX_GPA = 4.0;
    private static final int MIN_ID = 100000001;
    private static final int MAX_ID = 1000000000;

    @DomainConstraint(type = "Float", optional = false, min = MIN_GPA, max = MAX_GPA)
    private float gpa;

    /**
     * @effects
     *   <pre>
     *     if id, name, phoneNumber, address, gpa are valid
     *         set necessary attributes <id, name, phoneNumber, address, gpa>
     *     else throw NotPossibleException
     *   </pre>
     */
    public PostgradStudent(int id, String name, String phoneNumber, String address, float gpa) throws NotPossibleException {
        super(id, name, phoneNumber, address);
        if (!validateGpa(gpa) || !validateId(id)) {
            throw new NotPossibleException("Invalid GPA or ID for PostgradStudent " + name);
        }
        this.gpa = gpa;
    }

    // Getter
    /**
     * @effects
     *   <pre>
     *     return this.gpa
     *   </pre>
     */
    @DOpt(type = OptType.Observer) @AttrRef("gpa")
    public float getGpa() {
        return this.gpa;
    }

    // Setter
    /**
     * @effects
     *   <pre>
     *     if gpa is valid
     *         return true 
     *     else 
     *         return false
     *   </pre>
     */
    public boolean setGpa(float gpa) {
        if (validateGpa(gpa)) {
            this.gpa = gpa;
            return true;
        }
        return false;
    }

    // Helper method
    private boolean validateGpa(float gpa) {
        return gpa >= MIN_GPA && gpa <= MAX_GPA;
    }

    @Override
    @DomainConstraint(type = "Integer", mutable = false, optional = false, min = MIN_ID, max = MAX_ID)
    protected boolean validateId(int id) {
        return id >= MIN_ID && id <= MAX_ID;
    }

    /**
     * @effects
     *   <pre>
     *     if this satisfies abstract properties
     *         return true 
     *     else
     *         return false
     *   </pre>
     */
    @Override
    public boolean repOK() {
        return super.repOK() && validateGpa(gpa);
    }

    @Override
    public String toString() {
        return String.format("PostgradStudent:<%d, %s, %s, %s, %.2f>", this.getId(), this.getName(), this.getPhoneNumber(), this.getAddress(), this.getGpa());
    }

    @Override
    public String toHtmlDoc() {
        return String.format("<html>\n" +
                "<head><title>PostgradStudent:%d-%s</title></head>\n" +
                "<body>\n" +
                "%d %s %s %s %.2f\n" +
                "</body></html>", this.getId(), this.getName(), this.getId(), this.getName(), this.getPhoneNumber(), this.getAddress(), this.getGpa());
    }

    public static class Builder {
        private int id;
        private String name;
        private String phoneNumber;
        private String address;
        private float gpa;

        public Builder id(int id) {
            this.id = id;
            return this;
        }

        public Builder name(String name) {
            this.name = name;
            return this;
        }

        public Builder phoneNumber(String phoneNumber) {
            this.phoneNumber = phoneNumber;
            return this;
        }

        public Builder address(String address) {
            this.address = address;
            return this;
        }

        public Builder gpa(float gpa) {
            this.gpa = gpa;
            return this;
        }

        public PostgradStudent build() throws NotPossibleException {
            return new PostgradStudent(this);
        }
    }

    private PostgradStudent(Builder builder) throws NotPossibleException {
        this(builder.id, builder.name, builder.phoneNumber, builder.address, builder.gpa);
    }
}
