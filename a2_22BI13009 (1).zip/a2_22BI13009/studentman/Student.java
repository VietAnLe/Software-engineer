package a2_22BI13009.studentman;

import utils.*;

/**
 * @overview
 *   Representing a student
 *
 * @attributes
 *   id           Integer
 *   name         String
 *   phoneNumber  String
 *   address      String
 *
 * @object
 *   Contains information about a student: <id, name, phoneNumber, address>
 *
 * @abstract_properties
 *   id mutable: false, optional: false, min: 1, max: 1e9
 *   name mutable: true, optional: false, length: 50
 *   phoneNumber mutable: true, optional: false, length: 10
 *   address mutable: true, optional: false, length: 100
 */

public class Student implements Comparable<Student>, Document {
    private static final int MIN_ID = 1;
    private static final int MAX_ID = (int) 1e9;
    private static final int MAX_NAME_LENGTH = 50;
    private static final int MAX_PHONE_NUMBER_LENGTH = 10;
    private static final int MAX_ADDRESS_LENGTH = 100;

    @DomainConstraint(type = "Integer", mutable = false, optional = false, min = MIN_ID, max = MAX_ID)
    protected int id;
    @DomainConstraint(type = "String", optional = false, length = MAX_NAME_LENGTH)
    protected String name;
    @DomainConstraint(type = "String", optional = false, length = MAX_PHONE_NUMBER_LENGTH)
    protected String phoneNumber;
    @DomainConstraint(type = "String", optional = false, length = MAX_ADDRESS_LENGTH)
    protected String address;

    /**
     * Constructor
     * @effects
     *   Initialize a Student with id, name, phoneNumber, and address
     * @throws NotPossibleException
     *   if any of the preconditions are violated
     */
    public Student(@AttrRef("id") int id, @AttrRef("name") String name, @AttrRef("phoneNumber") String phoneNumber, @AttrRef("address") String address) 
            throws NotPossibleException {
        if (!validateId(id)) {
            throw new NotPossibleException("Student: Invalid id");
        }
        if (!validateName(name)) {
            throw new NotPossibleException("Student: Invalid name");
        }
        if (!validatePhoneNumber(phoneNumber)) {
            throw new NotPossibleException("Student: Invalid phone number");
        }
        if (!validateAddress(address)) {
            throw new NotPossibleException("Student: Invalid address");
        }
        this.id = id;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.address = address;
    }

    /**
     * Default constructor
     */
    public Student() {
        this.id = 0;
        this.name = "";
        this.phoneNumber = "";
        this.address = "";
    }

    // Id Getter
    @DOpt(type = OptType.Observer)
    @AttrRef("id")
    public int getId() {
        return id;
    }

    // Name Getter and Setter
    @DOpt(type = OptType.Observer)
    @AttrRef("name")
    public String getName() {
        return name;
    }

    @DOpt(type = OptType.Mutator)
    @AttrRef("name")
    public boolean setName(String name) {
        if (validateName(name)) {
            this.name = name;
            return true;
        }
        return false;
    }

    // PhoneNumber Getter and Setter
    @DOpt(type = OptType.Observer)
    @AttrRef("phoneNumber")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @DOpt(type = OptType.Mutator)
    @AttrRef("phoneNumber")
    public boolean setPhoneNumber(String phoneNumber) {
        if (validatePhoneNumber(phoneNumber)) {
            this.phoneNumber = phoneNumber;
            return true;
        }
        return false;
    }

    // Address Getter and Setter
    @DOpt(type = OptType.Observer)
    @AttrRef("address")
    public String getAddress() {
        return address;
    }

    @DOpt(type = OptType.Mutator)
    @AttrRef("address")
    public boolean setAddress(String address) {
        if (validateAddress(address)) {
            this.address = address;
            return true;
        }
        return false;
    }

    // Validation methods
    @DOpt(type = OptType.Helper)
    protected boolean validateId(int id) {
        boolean isValid = true;
        if (id < MIN_ID) {
            isValid = false;
        }
        if (id > MAX_ID) {
            isValid = false;
        }
        return isValid;
    }

    @DOpt(type = OptType.Helper)
    protected boolean validateName(String name) {
        boolean isValid = true;
        if (name == null) {
            isValid = false;
        }
        if (name != null && name.length() == 0) {
            isValid = false;
        }
        if (name != null && name.length() > MAX_NAME_LENGTH) {
            isValid = false;
        }
        return isValid;
    }

    @DOpt(type = OptType.Helper)
    protected boolean validatePhoneNumber(String phoneNumber) {
        boolean isValid = true;
        if (phoneNumber == null) {
            isValid = false;
        }
        if (phoneNumber != null && phoneNumber.length() == 0) {
            isValid = false;
        }
        if (phoneNumber != null && phoneNumber.length() > MAX_PHONE_NUMBER_LENGTH) {
            isValid = false;
        }
        return isValid;
    }

    @DOpt(type = OptType.Helper)
    protected boolean validateAddress(String address) {
        boolean isValid = true;
        if (address == null) {
            isValid = false;
        }
        if (address != null && address.length() == 0) {
            isValid = false;
        }
        if (address != null && address.length() > MAX_ADDRESS_LENGTH) {
            isValid = false;
        }
        return isValid;
    }

    // Other methods
    @Override
    @DOpt(type = OptType.Default)
    public int compareTo(Student std) {
        return this.name.compareTo(std.getName());
    }

    @Override
    @DOpt(type = OptType.Default)
    public String toHtmlDoc() {
        return String.format(
            "<html>\n<head><title>Student: %d - %s</title></head>\n<body>\n%s %s %s %s\n</body></html>",
            id, name, id, name, phoneNumber, address
        );
    }

    public boolean repOK() {
        return validateId(id) && validateName(name) && validatePhoneNumber(phoneNumber) && validateAddress(address);
    }

    @Override
    public String toString() {
        return String.format("Student(%d, %s, %s, %s)", id, name, phoneNumber, address);
    }
}
